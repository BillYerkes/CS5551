import { UclassifyService } from './../../services/uclassify.service';
import { Component, OnInit } from '@angular/core';
import {Observable} from 'rxjs';

@Component({
  selector: 'app-uclassify',
  templateUrl: './uclassify.page.html',
  styleUrls: ['./uclassify.page.scss'],
})
export class UclassifyPage implements OnInit {

  results: Observable<any>;
  information = null;
  searchTerm: string = '';
  item;

  constructor(private uclassifyService: UclassifyService) { }

  btnClick(){
    console.log(this.searchTerm);
    /*this.results  = this.uclassifyService.sentiment(this.searchTerm);*/


    this.item = this.uclassifyService.sentiment(this.searchTerm);

    console.log(this.information);
  }

  ngOnInit() {
  }

}
