import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { UclassifyPageRoutingModule } from './uclassify-routing.module';

import { UclassifyPage } from './uclassify.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    UclassifyPageRoutingModule
  ],
  declarations: [UclassifyPage]
})
export class UclassifyPageModule {}
