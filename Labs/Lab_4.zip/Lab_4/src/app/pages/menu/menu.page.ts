import { Component, OnInit } from '@angular/core';
import {Router, Event, RouterEvent} from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.page.html',
  styleUrls: ['./menu.page.scss'],
})
export class MenuPage implements OnInit {
  public pages = [
     {
      title: 'Movies',
      url: '/menu/movies'
    },
    {
      title: 'U-Classify',
      url: '/menu/uclassify'
    }
  ];

  selectedPath = '';

  constructor(private router: Router) {
    this.router.events.subscribe((event: RouterEvent) => {
      this.selectedPath = event.url;
    });
  }

  ngOnInit() {
  }

}
