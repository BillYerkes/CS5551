import { TestBed } from '@angular/core/testing';

import { UclassifyService } from './uclassify.service';

describe('UclassifyService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UclassifyService = TestBed.get(UclassifyService);
    expect(service).toBeTruthy();
  });
});
