import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class UclassifyService {
  url = 'https://api.uclassify.com/v1/';
  apiKey = 'YSjbCbwvtWod'; // <-- Enter your own key here!
  classifierName = 'uClassify/Sentiment/classify';
  item;
  information = null;

  /**
   * Constructor of the Service with Dependency Injection
   * @param http The standard Angular HttpClient to make requests
   */
  constructor(private http: HttpClient) { }

  /**
   * Get data from the OmdbApi
   * map the result to return only the results that we need
   *
   * @param {string} title Search Term
   * @param {SearchType} type movie, series, episode or empty
   * @returns Observable with the search results
   */
  sentiment(text: string) {
    console.log(text);
    console.log(`${this.url + this.classifierName}?readKey=${this.apiKey}&text=${text}`);

    this.http.post( )
    this.http.get(`${this.url + this.classifierName}?readKey=${this.apiKey}&text=${text}` )
        .subscribe({
          next(num){console.log('a' + num); }
        });

    /*
    this.http.get(`${this.url + this.classifierName}?readKey=${this.apiKey}&text=${text}` ).subscribe((data: any) => this.item = {

      positive: data.fields.positive,
      negative: data.negative
    });
    console.log(this.item);
    */

    return this.item;

  }


}
